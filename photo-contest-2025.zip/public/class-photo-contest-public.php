<?php
class Photo_Contest_Public {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;

        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function enqueue_styles() {
        wp_enqueue_style(
            $this->plugin_name . '-submission',
            plugin_dir_url(__FILE__) . 'css/submission-style.css',
            array(),
            $this->version,
            'all'
        );
    }

    public function enqueue_scripts() {
        wp_enqueue_script(
            $this->plugin_name . '-validation',
            plugin_dir_url(__FILE__) . 'js/submission-validation.js',
            array('jquery'),
            $this->version,
            true
        );

        // Localize script for translations and variables
        wp_localize_script(
            $this->plugin_name . '-validation',
            'photoContestSubmission',
            array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('photo_contest_submission'),
                'maxFileSize' => 5 * 1024 * 1024,
                'messages' => array(
                    'fileTooLarge' => 'File size must be less than 5MB',
                    'invalidType' => 'Please upload a valid image file',
                    'uploading' => 'Uploading...'
                )
            )
        );
    }
}
