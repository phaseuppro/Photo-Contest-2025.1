jQuery(document).ready(function($) {
    $('.vote-button').on('click', function() {
        const button = $(this);
        const submissionId = button.data('submission-id');
        
        button.prop('disabled', true).text('Voting...');
        
        $.ajax({
            url: photoContestGallery.ajaxurl,
            type: 'POST',
            data: {
                action: 'photo_contest_vote',
                submission_id: submissionId,
                nonce: photoContestGallery.nonce
            },
            success: function(response) {
                if (response.success) {
                    const votesCount = button.closest('.photo-meta').find('.votes-count');
                    votesCount.text(response.data.votes + ' votes');
                    button.text('Voted').addClass('voted');
                } else {
                    button.text('Vote').prop('disabled', false);
                    alert(response.data.message);
                }
            },
            error: function() {
                button.text('Vote').prop('disabled', false);
                alert('Voting failed. Please try again.');
            }
        });
    });
});
