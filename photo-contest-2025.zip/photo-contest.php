<?php
/**
 * Plugin Name: Photo Contest 2025
 * Plugin URI: https://yourwebsite.com/photo-contest
 * Description: Modern photo contest plugin with voting system
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: photo-contest
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PHOTO_CONTEST_VERSION', '1.0.0');
define('PHOTO_CONTEST_PATH', plugin_dir_path(__FILE__));
define('PHOTO_CONTEST_URL', plugin_dir_url(__FILE__));

// Activation Hook
register_activation_hook(__FILE__, 'photo_contest_activate');
function photo_contest_activate() {
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-activator.php';
    Photo_Contest_Activator::activate();
}

// Deactivation Hook
register_deactivation_hook(__FILE__, 'photo_contest_deactivate');
function photo_contest_deactivate() {
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-deactivator.php';
    Photo_Contest_Deactivator::deactivate();
}

// Load core plugin class
require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest.php';

// Initialize Plugin
function run_photo_contest() {
    $plugin = new Photo_Contest();
    $plugin->run();
}
run_photo_contest();
