<?php
class Photo_Contest_Notifications {
    public function __construct() {
        add_action('photo_contest_submission_approved', array($this, 'notify_submission_approved'), 10, 2);
        add_action('photo_contest_winner_selected', array($this, 'notify_contest_winner'), 10, 2);
        add_action('photo_contest_new_submission', array($this, 'notify_admin_new_submission'), 10, 2);
    }

    public function notify_submission_approved($submission_id, $user_id) {
        $user = get_userdata($user_id);
        $subject = __('Your photo submission has been approved!', 'photo-contest');
        
        $message = sprintf(
            __('Hello %s,\n\nYour photo submission has been approved and is now visible in the contest gallery.\n\nBest regards,\nThe Contest Team', 'photo-contest'),
            $user->display_name
        );

        wp_mail($user->user_email, $subject, $message);
    }

    public function notify_contest_winner($contest_id, $user_id) {
        $user = get_userdata($user_id);
        $contest = $this->get_contest($contest_id);
        
        $subject = sprintf(__('Congratulations! You won the %s contest!', 'photo-contest'), $contest->title);
        
        $message = sprintf(
            __('Hello %s,\n\nCongratulations! Your photo won the %s contest!\n\nBest regards,\nThe Contest Team', 'photo-contest'),
            $user->display_name,
            $contest->title
        );

        wp_mail($user->user_email, $subject, $message);
    }

    public function notify_admin_new_submission($submission_id, $contest_id) {
        $admin_email = get_option('admin_email');
        $contest = $this->get_contest($contest_id);
        
        $subject = sprintf(__('New photo submission for %s', 'photo-contest'), $contest->title);
        
        $message = sprintf(
            __('A new photo has been submitted to the contest "%s".\n\nPlease review it in the admin panel.\n\nBest regards,\nYour Website', 'photo-contest'),
            $contest->title
        );

        wp_mail($admin_email, $subject, $message);
    }

    private function get_contest($contest_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'photo_contests';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $contest_id));
    }
}
