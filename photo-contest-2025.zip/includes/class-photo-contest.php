<?php
class Photo_Contest {
    protected $loader;
    protected $plugin_name;
    protected $version;
    protected $results;
    protected $notifications;

    public function __construct() {
        $this->version = PHOTO_CONTEST_VERSION;
        $this->plugin_name = 'photo-contest';
        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
        $this->init_results();
        $this->init_notifications();
    }

    private function load_dependencies() {
        // Core plugin functionality
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-loader.php';
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-results.php';
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-notifications.php';
        require_once PHOTO_CONTEST_PATH . 'admin/class-photo-contest-admin.php';
        require_once PHOTO_CONTEST_PATH . 'public/class-photo-contest-public.php';
        
        $this->loader = new Photo_Contest_Loader();
    }

    private function init_results() {
        $this->results = new Photo_Contest_Results();
    }

    private function init_notifications() {
        $this->notifications = new Photo_Contest_Notifications();
    }

    private function set_locale() {
        add_action('plugins_loaded', array($this, 'load_plugin_textdomain'));
    }

    public function load_plugin_textdomain() {
        load_plugin_textdomain(
            'photo-contest',
            false,
            dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );
    }

    private function define_admin_hooks() {
        $plugin_admin = new Photo_Contest_Admin($this->get_plugin_name(), $this->get_version());
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
    }

    private function define_public_hooks() {
        $plugin_public = new Photo_Contest_Public($this->get_plugin_name(), $this->get_version());
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
    }

    public function run() {
        $this->loader->run();
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }
}
