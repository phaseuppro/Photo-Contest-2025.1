<?php
class Photo_Contest_Manager {
    private $wpdb;
    private $contests_table;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->contests_table = $wpdb->prefix . 'photo_contests';
    }

    public function create_contest($data) {
        return $this->wpdb->insert(
            $this->contests_table,
            array(
                'title' => sanitize_text_field($data['contest_title']),
                'description' => sanitize_textarea_field($data['contest_description']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'status' => 'draft',
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );
    }

    public function get_all_contests() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->contests_table} ORDER BY created_at DESC"
        );
    }

    public function get_contest($id) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->contests_table} WHERE id = %d",
                $id
            )
        );
    }

    public function update_contest($id, $data) {
        return $this->wpdb->update(
            $this->contests_table,
            array(
                'title' => sanitize_text_field($data['contest_title']),
                'description' => sanitize_textarea_field($data['contest_description']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'status' => $data['status']
            ),
            array('id' => $id),
            array('%s', '%s', '%s', '%s', '%s'),
            array('%d')
        );
    }

    public function delete_contest($id) {
        return $this->wpdb->delete(
            $this->contests_table,
            array('id' => $id),
            array('%d')
        );
    }
}
