<?php
class Photo_Contest_Voting {
    private $wpdb;
    private $submissions_table;
    private $votes_table;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->submissions_table = $wpdb->prefix . 'photo_submissions';
        $this->votes_table = $wpdb->prefix . 'photo_contest_votes';
        
        add_action('wp_ajax_photo_contest_vote', array($this, 'handle_vote'));
        add_action('wp_ajax_nopriv_photo_contest_vote', array($this, 'handle_unauthorized_vote'));
    }

    public function handle_vote() {
        check_ajax_referer('photo_contest_vote', 'nonce');
        
        $submission_id = intval($_POST['submission_id']);
        $user_id = get_current_user_id();
        
        // Check if user already voted
        $existing_vote = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT id FROM {$this->votes_table} WHERE submission_id = %d AND user_id = %d",
            $submission_id,
            $user_id
        ));

        if ($existing_vote) {
            wp_send_json_error(array('message' => 'You have already voted for this photo'));
            return;
        }

        // Record the vote
        $result = $this->wpdb->insert(
            $this->votes_table,
            array(
                'submission_id' => $submission_id,
                'user_id' => $user_id,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%d', '%s')
        );

        if ($result) {
            // Update submission votes count
            $this->wpdb->query($this->wpdb->prepare(
                "UPDATE {$this->submissions_table} SET votes_count = votes_count + 1 WHERE id = %d",
                $submission_id
            ));

            $new_votes_count = $this->wpdb->get_var($this->wpdb->prepare(
                "SELECT votes_count FROM {$this->submissions_table} WHERE id = %d",
                $submission_id
            ));

            wp_send_json_success(array(
                'votes' => $new_votes_count,
                'message' => 'Vote recorded successfully'
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to record vote'));
        }
    }

    public function handle_unauthorized_vote() {
        wp_send_json_error(array(
            'message' => 'Please login to vote',
            'redirect' => wp_login_url($_SERVER['HTTP_REFERER'])
        ));
    }

    public function get_user_votes($user_id) {
        return $this->wpdb->get_col($this->wpdb->prepare(
            "SELECT submission_id FROM {$this->votes_table} WHERE user_id = %d",
            $user_id
        ));
    }
}
