<?php
class Photo_Contest_Admin {
    private $plugin_name;
    private $version;
    private $contest_manager;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-manager.php';
        $this->contest_manager = new Photo_Contest_Manager();
        
        add_action('admin_menu', array($this, 'add_plugin_admin_menu'));
        add_action('admin_post_create_photo_contest', array($this, 'handle_contest_creation'));
        add_action('admin_post_update_photo_contest', array($this, 'handle_contest_update'));
        add_action('admin_post_delete_photo_contest', array($this, 'handle_contest_deletion'));
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            'Photo Contest', 
            'Photo Contest', 
            'manage_options', 
            'photo-contest',
            array($this, 'display_plugin_admin_page'),
            'dashicons-format-gallery',
            30
        );

        add_submenu_page(
            'photo-contest',
            'All Contests',
            'All Contests',
            'manage_options',
            'photo-contest',
            array($this, 'display_plugin_admin_page')
        );

        add_submenu_page(
            'photo-contest',
            'Add New Contest',
            'Add New Contest',
            'manage_options',
            'photo-contest-new',
            array($this, 'display_add_new_contest')
        );

        add_submenu_page(
            null, // Hidden from menu
            'Edit Contest',
            'Edit Contest',
            'manage_options',
            'photo-contest-edit',
            array($this, 'display_edit_contest')
        );
    }

    public function display_edit_contest() {
        require_once plugin_dir_path(__FILE__) . 'partials/admin-edit-contest.php';
    }

    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/admin-style.css', array(), $this->version, 'all');
        wp_enqueue_style('jquery-ui-datepicker');
    }

    public function enqueue_scripts() {
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/admin-script.js', array('jquery'), $this->version, false);
        
        wp_localize_script($this->plugin_name, 'photoContest', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('photo_contest_nonce')
        ));
    }

    public function display_plugin_admin_page() {
        $contests = $this->contest_manager->get_all_contests();
        require_once plugin_dir_path(__FILE__) . 'partials/admin-display.php';
    }

    public function display_add_new_contest() {
        require_once plugin_dir_path(__FILE__) . 'partials/admin-new-contest.php';
    }

    public function handle_contest_creation() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        check_admin_referer('create_photo_contest', 'photo_contest_nonce');

        $contest_data = array(
            'contest_title' => sanitize_text_field($_POST['contest_title']),
            'contest_description' => sanitize_textarea_field($_POST['contest_description']),
            'start_date' => sanitize_text_field($_POST['start_date']),
            'end_date' => sanitize_text_field($_POST['end_date'])
        );

        $result = $this->contest_manager->create_contest($contest_data);

        if ($result) {
            wp_redirect(admin_url('admin.php?page=photo-contest&message=created'));
        } else {
            wp_redirect(admin_url('admin.php?page=photo-contest&message=error'));
        }
        exit;
    }

    public function handle_contest_update() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        check_admin_referer('update_photo_contest', 'photo_contest_nonce');

        $contest_id = intval($_POST['contest_id']);
        $contest_data = array(
            'contest_title' => sanitize_text_field($_POST['contest_title']),
            'contest_description' => sanitize_textarea_field($_POST['contest_description']),
            'start_date' => sanitize_text_field($_POST['start_date']),
            'end_date' => sanitize_text_field($_POST['end_date']),
            'status' => sanitize_text_field($_POST['status'])
        );

        $result = $this->contest_manager->update_contest($contest_id, $contest_data);

        if ($result) {
            wp_redirect(admin_url('admin.php?page=photo-contest&message=updated'));
        } else {
            wp_redirect(admin_url('admin.php?page=photo-contest&message=error'));
        }
        exit;
    }

    public function handle_contest_deletion() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        check_admin_referer('delete_photo_contest', 'photo_contest_nonce');

        $contest_id = intval($_POST['contest_id']);
        $result = $this->contest_manager->delete_contest($contest_id);

        if ($result) {
            wp_redirect(admin_url('admin.php?page=photo-contest&message=deleted'));
        } else {
            wp_redirect(admin_url('admin.php?page=photo-contest&message=error'));
        }
        exit;
    }
}
