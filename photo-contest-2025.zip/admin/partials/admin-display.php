<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap photo-contest-admin">
    <h1>Add New Photo Contest</h1>

    <form method="post" action="" class="photo-contest-form">
        <?php wp_nonce_field('create_photo_contest', 'photo_contest_nonce'); ?>
        
        <div class="form-field">
            <label for="contest-title">Contest Title *</label>
            <input type="text" id="contest-title" name="contest_title" required>
        </div>

        <div class="form-field">
            <label for="contest-description">Description</label>
            <textarea id="contest-description" name="contest_description" rows="5"></textarea>
        </div>

        <div class="form-field">
            <label for="start-date">Start Date *</label>
            <input type="date" id="start-date" name="start_date" required>
        </div>

        <div class="form-field">
            <label for="end-date">End Date *</label>
            <input type="date" id="end-date" name="end_date" required>
        </div>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="Create Contest">
        </p>
    </form>
</div>
